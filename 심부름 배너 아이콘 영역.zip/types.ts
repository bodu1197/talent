export enum Category {
  DELIVERY = '배달/운반',
  CLEANING = '청소/집안일',
  QUEUEING = '줄서기',
  BUG_CATCHING = '벌레잡기',
  PET_CARE = '반려동물 케어',
  SHOPPING = '구매대행',
  OTHER = '기타',
}

export enum WeightClass {
  LIGHT = '가벼움 (서류/음식)',
  MEDIUM = '보통 (장바구니/박스)',
  HEAVY = '무거움 (가구/가전)',
}

export type WeatherCondition = 'CLEAR' | 'RAIN' | 'SNOW' | 'EXTREME';
export type TimeCondition = 'DAY' | 'LATE_NIGHT' | 'RUSH_HOUR';

export interface HelperInfo {
  id?: string;
  name: string;
  avatar: string;
  currentLat: number; // For simulation (0-100 scale)
  currentLng: number; // For simulation (0-100 scale)
  rating?: number;
  reviews?: number;
  distance?: number; // km from user
  status?: 'IDLE' | 'BUSY';
  specialties?: Category[];
}

export interface Errand {
  id: string;
  title: string;
  description: string;
  category: Category;
  price: number;
  createdAt: number;
  status: 'OPEN' | 'IN_PROGRESS' | 'COMPLETED';
  
  // Locations
  startLocation: string; // 출발지
  endLocation: string;   // 도착지 (기존 location 대체)
  
  // Smart Context Fields
  distance: number; // km
  weather: WeatherCondition;
  timeOfDay: TimeCondition;
  weightClass: WeightClass;
  isRecurring?: boolean;
  helper?: HelperInfo;
}

export interface AIAnalysisResult {
  title: string;
  description: string;
  category: Category;
  startLocation: string;
  endLocation: string;
  estimatedWeight: WeightClass;
  estimatedDistance: number;
}