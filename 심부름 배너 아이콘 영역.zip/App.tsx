import React, { useState } from 'react';
import { HashRouter, Routes, Route, useParams } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Hero } from './components/Hero';
import { ActiveHelpers } from './components/ActiveHelpers';
import { ErrandList } from './components/ErrandList';
import { ErrandForm } from './components/ErrandForm';
import { DeliveryTracker } from './components/DeliveryTracker';
import { Errand, Category, WeightClass } from './types';

// Mock Initial Data
const INITIAL_ERRANDS: Errand[] = [
  {
    id: '1',
    title: '비오는데 강남역 쉑쉑버거 배달해주실 분',
    description: '쉑쉑버거 기본 세트 1개요. 비와서 나가기가 힘드네요. 문앞 배달 부탁드려요.',
    category: Category.DELIVERY,
    price: 18000,
    startLocation: '강남역 1번 출구',
    endLocation: '역삼동 푸르지오',
    createdAt: Date.now(),
    status: 'IN_PROGRESS',
    distance: 1.2,
    weather: 'RAIN',
    timeOfDay: 'DAY',
    weightClass: WeightClass.LIGHT,
    helper: {
      name: '이동현',
      avatar: '',
      currentLat: 0,
      currentLng: 0
    }
  },
  {
    id: '2',
    title: '집에 바퀴벌레가 나왔어요 ㅠㅠ',
    description: '엄지손가락 만한 바퀴벌레가 거실에... 못 잡겠어요 제발 도와주세요. 잡고 처리까지 부탁드립니다.',
    category: Category.BUG_CATCHING,
    price: 30000,
    startLocation: '방배동 현위치',
    endLocation: '방배동 현위치',
    createdAt: Date.now() - 3600000,
    status: 'OPEN',
    distance: 0.5,
    weather: 'CLEAR',
    timeOfDay: 'LATE_NIGHT',
    weightClass: WeightClass.LIGHT
  },
  {
    id: '3',
    title: '성수동 팝업스토어 줄서기 (매주)',
    description: '매주 토요일 아침 8시부터 10시까지 2시간 줄서주실 분 구합니다.',
    category: Category.QUEUEING,
    price: 25000,
    startLocation: '성수동 디올',
    endLocation: '성수동 디올',
    createdAt: Date.now() - 7200000,
    status: 'OPEN',
    isRecurring: true,
    weather: 'CLEAR',
    timeOfDay: 'DAY',
    weightClass: WeightClass.LIGHT,
    distance: 0
  },
   {
    id: '4',
    title: '원룸 입주 청소',
    description: '6평 원룸 입주 청소 부탁드립니다. 화장실 포함.',
    category: Category.CLEANING,
    price: 50000,
    startLocation: '신림동 123-4',
    endLocation: '신림동 123-4',
    createdAt: Date.now() - 100000,
    status: 'OPEN',
    weather: 'CLEAR',
    timeOfDay: 'DAY',
    weightClass: WeightClass.MEDIUM,
    distance: 0
  }
];

const TrackerPage = ({ errands }: { errands: Errand[] }) => {
    const { id } = useParams();
    const errand = errands.find(e => e.id === id);
    
    if (!errand) return <div className="p-8 text-center text-gray-500">요청을 찾을 수 없습니다.</div>;
    
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold">배달 현황 확인</h1>
            <div className="bg-white p-6 rounded-2xl shadow-sm">
                <div className="mb-4 pb-4 border-b border-gray-100">
                    <h3 className="text-lg font-bold">{errand.title}</h3>
                    <p className="text-gray-500">{errand.description}</p>
                </div>
                <DeliveryTracker errand={errand} />
            </div>
        </div>
    );
};

const App: React.FC = () => {
  const [errands, setErrands] = useState<Errand[]>(INITIAL_ERRANDS);

  const handleCreateErrand = (newErrandData: Omit<Errand, 'id' | 'createdAt' | 'status'>) => {
    const newErrand: Errand = {
      ...newErrandData,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: Date.now(),
      status: 'OPEN',
      // If it's delivery, we can auto-assign a mock helper for demo purposes
      helper: newErrandData.category === Category.DELIVERY ? {
          name: 'AI 매칭 헬퍼',
          avatar: '',
          currentLat: 0,
          currentLng: 0
      } : undefined
    };
    
    // For demo: if delivery, set to In Progress immediately to show tracker
    if (newErrand.category === Category.DELIVERY) {
        newErrand.status = 'IN_PROGRESS';
    }

    setErrands([newErrand, ...errands]);
  };

  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={
            <div className="space-y-6">
              <Hero />
              <ActiveHelpers />
              <div className="h-2 bg-gray-100 -mx-4 md:hidden"></div>
              <ErrandList errands={errands} />
            </div>
          } />
          <Route path="/list" element={<ErrandList errands={errands} />} />
          <Route path="/create" element={<ErrandForm onSubmit={handleCreateErrand} />} />
          <Route path="/track/:id" element={<TrackerPage errands={errands} />} />
          <Route path="/profile" element={
            <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border border-gray-100">
               <div className="w-20 h-20 bg-gray-200 rounded-full mb-4"></div>
               <h2 className="text-xl font-bold">로그인이 필요합니다</h2>
               <p className="text-gray-500 mb-6">로그인 후 내 정보를 확인하세요.</p>
               <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium">카카오 로그인</button>
            </div>
          } />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;