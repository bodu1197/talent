import React, { useEffect, useState } from 'react';
import { Errand } from '../types';
import { MapPin, Navigation, Phone, MessageCircle, Clock, CheckCircle2 } from 'lucide-react';

interface DeliveryTrackerProps {
  errand: Errand;
}

export const DeliveryTracker: React.FC<DeliveryTrackerProps> = ({ errand }) => {
  const [progress, setProgress] = useState(0);
  
  // Simulation Loop
  useEffect(() => {
    if (errand.status === 'COMPLETED') {
      setProgress(100);
      return;
    }

    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 0.5; // Simulate movement speed
      });
    }, 100);

    return () => clearInterval(interval);
  }, [errand.status]);

  // Calculate ETA based on remaining distance (assuming avg speed 20km/h for bike/scooter)
  const totalDistance = errand.distance || 2.0; 
  const remainingDistance = totalDistance * (1 - progress / 100);
  const etaMinutes = Math.ceil((remainingDistance / 20) * 60);

  // Helper Mock Data (in real app, this comes from DB)
  const helperName = errand.helper?.name || "김철수 헬퍼";
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">실시간 배달/이동 현황</h2>
        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
          실시간 추적중
        </span>
      </div>

      {/* Map Simulation Area */}
      <div className="relative w-full h-72 bg-gray-100 rounded-2xl overflow-hidden shadow-inner border border-gray-200">
        {/* Background Map Grid */}
        <div className="absolute inset-0 opacity-10" 
             style={{
               backgroundImage: 'linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)',
               backgroundSize: '20px 20px'
             }}>
        </div>

        {/* Path Visualization */}
        <svg className="absolute inset-0 w-full h-full p-8">
           {/* Path Line */}
           <line x1="15%" y1="50%" x2="85%" y2="50%" stroke="#E5E7EB" strokeWidth="8" strokeLinecap="round" />
           <line x1="15%" y1="50%" x2={`${15 + (progress * 0.7)}%`} y2="50%" stroke="#3B82F6" strokeWidth="8" strokeLinecap="round" />

           {/* Start Point */}
           <g transform="translate(15%, 50%)">
             <circle cx="0" cy="0" r="8" fill="#9CA3AF" />
             <text x="0" y="25" textAnchor="middle" className="text-xs fill-gray-600 font-bold">{errand.startLocation}</text>
           </g>

           {/* End Point */}
           <g transform="translate(85%, 50%)">
             <circle cx="0" cy="0" r="8" fill="#EF4444" />
             <text x="0" y="25" textAnchor="middle" className="text-xs fill-gray-600 font-bold">{errand.endLocation}</text>
           </g>

           {/* Moving Helper Marker */}
           <g transform={`translate(${15 + (progress * 0.7)}%, 50%)`}>
             <circle r="14" fill="white" stroke="#3B82F6" strokeWidth="4" />
             <Navigation size={16} className="text-blue-600 -translate-x-2 -translate-y-2" />
             
             {/* Tooltip */}
             <g transform="translate(-35, -45)">
               <rect width="70" height="26" rx="6" fill="black" fillOpacity="0.8" />
               <text x="35" y="17" textAnchor="middle" fill="white" fontSize="11" fontWeight="bold">
                 {remainingDistance.toFixed(1)}km 남음
               </text>
               <path d="M30,26 L35,32 L40,26 Z" fill="black" fillOpacity="0.8" />
             </g>
           </g>
        </svg>

        {/* Weather Overlay */}
        {errand.weather === 'RAIN' && (
           <div className="absolute inset-0 pointer-events-none bg-blue-900/10 mix-blend-overlay backdrop-blur-[1px]"></div>
        )}
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
            <Clock size={20} />
          </div>
          <div>
            <div className="text-xs text-gray-500">도착 예정</div>
            <div className="text-lg font-bold">{progress >= 100 ? '도착완료' : `${etaMinutes}분 후`}</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
            <MapPin size={20} />
          </div>
          <div>
             <div className="text-xs text-gray-500">남은 거리</div>
             <div className="text-lg font-bold">{remainingDistance.toFixed(1)}km</div>
          </div>
        </div>
      </div>

      {/* Helper Profile */}
      <div className="bg-gray-900 text-white p-5 rounded-2xl flex items-center justify-between shadow-lg">
         <div className="flex items-center gap-3">
           <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center border-2 border-green-400">
             <span className="font-bold text-lg">👷</span>
           </div>
           <div>
             <div className="flex items-center gap-2">
                 <h3 className="font-bold">{helperName}</h3>
                 <span className="text-[10px] bg-green-500 text-white px-1.5 rounded font-bold">인증됨</span>
             </div>
             <p className="text-gray-400 text-xs mt-0.5">안전하게 이동 중입니다</p>
           </div>
         </div>
         <div className="flex gap-2">
           <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-full transition"><Phone size={18}/></button>
           <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-full transition"><MessageCircle size={18}/></button>
         </div>
      </div>
    </div>
  );
};