import React, { useEffect, useState } from 'react';
import { ArrowRight, MapPin, Zap, Shield, Navigation } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Hero: React.FC = () => {
  const [pulse, setPulse] = useState(false);
  const [nearbyCount, setNearbyCount] = useState(3);

  useEffect(() => {
    // Pulse animation trigger
    const interval = setInterval(() => {
      setPulse(prev => !prev);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full overflow-hidden bg-gray-900 rounded-3xl shadow-2xl mb-8 border border-gray-800">
      {/* Background Map Effect */}
      <div className="absolute inset-0 opacity-20" 
           style={{
             backgroundImage: 'radial-gradient(#4B5563 1px, transparent 1px)',
             backgroundSize: '24px 24px'
           }}>
      </div>
      
      {/* Content Overlay */}
      <div className="relative z-10 p-6 md:p-10 flex flex-col items-center justify-center text-center min-h-[400px]">
        
        {/* Radar Visualization */}
        <div className="relative w-64 h-64 mb-8 flex items-center justify-center">
            {/* Center User */}
            <div className="absolute w-4 h-4 bg-blue-500 rounded-full z-20 shadow-[0_0_20px_rgba(59,130,246,0.8)] animate-pulse"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-500/20 w-16 h-16 rounded-full blur-md"></div>
            
            {/* Ripples */}
            <div className="absolute inset-0 rounded-full border border-blue-500/30 animate-[ping_3s_ease-in-out_infinite]"></div>
            <div className="absolute inset-4 rounded-full border border-blue-500/20 animate-[ping_3s_ease-in-out_infinite_1s]"></div>
            <div className="absolute inset-12 rounded-full border border-blue-500/10 animate-[ping_3s_ease-in-out_infinite_2s]"></div>

            {/* Orbiting Helpers (Simulated) */}
            <div className="absolute top-10 left-10 animate-bounce duration-1000">
                <div className="w-8 h-8 rounded-full bg-white border-2 border-green-500 flex items-center justify-center overflow-hidden shadow-lg">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Helper" />
                </div>
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap">
                    300m
                </div>
            </div>

            <div className="absolute bottom-8 right-12 animate-bounce duration-[2000ms]">
                <div className="w-8 h-8 rounded-full bg-white border-2 border-green-500 flex items-center justify-center overflow-hidden shadow-lg">
                     <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka" alt="Helper" />
                </div>
                 <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap">
                    0.8km
                </div>
            </div>

             <div className="absolute top-1/2 right-4 animate-bounce duration-[1500ms]">
                <div className="w-8 h-8 rounded-full bg-white border-2 border-green-500 flex items-center justify-center overflow-hidden shadow-lg">
                     <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=John" alt="Helper" />
                </div>
                 <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap">
                    1.2km
                </div>
            </div>
        </div>

        {/* Status Text */}
        <div className="space-y-2 max-w-md mx-auto">
            <div className="inline-flex items-center gap-2 bg-gray-800/80 backdrop-blur border border-gray-700 rounded-full px-4 py-1.5 text-sm text-blue-300 mb-2">
                <MapPin size={14} className="animate-pulse"/>
                <span>서울시 강남구 역삼동 기준</span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold text-white leading-tight">
                내 주변 <span className="text-green-400">{nearbyCount}명의 헬퍼</span>가<br/>
                대기하고 있어요
            </h1>
            
            <p className="text-gray-400 text-sm md:text-base mb-6">
                지금 요청하면 평균 <span className="text-white font-bold">5분 내</span> 매칭됩니다.
            </p>

            <div className="flex w-full gap-3">
                 <Link to="/create" className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-blue-900/50 flex items-center justify-center gap-2 transition transform active:scale-95">
                    <Zap size={20} fill="currentColor" />
                    지금 호출하기
                </Link>
            </div>
        </div>
      </div>
      
      {/* Bottom Ticker */}
      <div className="absolute bottom-0 w-full bg-gray-900/90 border-t border-gray-800 p-3 flex justify-around text-xs text-gray-400">
         <div className="flex items-center gap-1.5">
            <Shield size={14} className="text-green-500"/>
            <span>신원검증 완료</span>
         </div>
         <div className="flex items-center gap-1.5">
            <Navigation size={14} className="text-blue-500"/>
            <span>실시간 경로 추적</span>
         </div>
      </div>
    </div>
  );
};