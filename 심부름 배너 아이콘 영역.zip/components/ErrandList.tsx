import React, { useState } from 'react';
import { Errand, Category } from '../types';
import { MapPin, Clock, Filter, CloudRain, Snowflake, Moon, Repeat, Navigation, ArrowRight, Package } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ErrandListProps {
  errands: Errand[];
}

export const ErrandList: React.FC<ErrandListProps> = ({ errands }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'ALL'>('ALL');

  const filteredErrands = selectedCategory === 'ALL' 
    ? errands 
    : errands.filter(e => e.category === selectedCategory);

  const getCategoryColor = (cat: Category) => {
    switch (cat) {
      case Category.DELIVERY: return 'bg-blue-100 text-blue-700';
      case Category.CLEANING: return 'bg-teal-100 text-teal-700';
      case Category.BUG_CATCHING: return 'bg-red-100 text-red-700';
      case Category.QUEUEING: return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">주변 요청 목록</h2>
        <span className="text-sm text-gray-500">{filteredErrands.length}건의 요청</span>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        <button 
          onClick={() => setSelectedCategory('ALL')}
          className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition ${selectedCategory === 'ALL' ? 'bg-gray-900 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          전체
        </button>
        {Object.values(Category).map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition ${selectedCategory === cat ? 'bg-gray-900 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredErrands.map((errand) => (
          <div key={errand.id} className="bg-white p-0 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition cursor-pointer group relative overflow-hidden flex flex-col">
            
            {/* Header: Price & Category */}
            <div className="p-5 pb-2">
                <div className="flex justify-between items-start mb-2">
                    <span className={`px-2.5 py-1 rounded-md text-xs font-bold ${getCategoryColor(errand.category)}`}>
                        {errand.category}
                    </span>
                    <div className="text-right">
                        <span className="text-lg font-bold text-gray-900 block">
                            {errand.price.toLocaleString()}원
                        </span>
                    </div>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-1 group-hover:text-blue-600 transition truncate">
                  {errand.title}
                </h3>
            </div>

            {/* Route Visualization */}
            <div className="px-5 py-3 bg-gray-50 border-t border-b border-gray-100">
                <div className="flex items-center gap-2 text-sm">
                    <div className="flex items-center gap-1 text-gray-600 max-w-[40%] truncate">
                        <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0"></span>
                        <span className="truncate">{errand.startLocation}</span>
                    </div>
                    <ArrowRight size={14} className="text-gray-400 shrink-0" />
                    <div className="flex items-center gap-1 text-gray-600 max-w-[40%] truncate">
                        <span className="w-2 h-2 rounded-full bg-red-500 shrink-0"></span>
                        <span className="truncate">{errand.endLocation}</span>
                    </div>
                </div>
            </div>
            
            {/* Footer: Tags & Status */}
            <div className="p-4 pt-3 mt-auto flex items-center justify-between">
                <div className="flex gap-1">
                    {errand.weather === 'RAIN' && <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded text-xs flex items-center gap-1"><CloudRain size={12}/> 우천</span>}
                    {errand.timeOfDay === 'LATE_NIGHT' && <span className="px-2 py-1 bg-purple-50 text-purple-600 rounded text-xs flex items-center gap-1"><Moon size={12}/> 심야</span>}
                    {errand.weightClass !== '가벼움 (서류/음식)' && <span className="px-2 py-1 bg-orange-50 text-orange-600 rounded text-xs flex items-center gap-1"><Package size={12}/> 무거움</span>}
                </div>

                {errand.status === 'IN_PROGRESS' ? (
                    <Link to={`/track/${errand.id}`} className="flex items-center gap-1 text-white text-xs font-bold bg-green-500 px-3 py-1.5 rounded-full hover:bg-green-600 transition shadow-sm" onClick={(e) => e.stopPropagation()}>
                        <Navigation size={12} />
                        <span>위치 추적</span>
                    </Link>
                ) : (
                    <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded">대기중</span>
                )}
            </div>
          </div>
        ))}
      </div>
      
      {filteredErrands.length === 0 && (
        <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-300">
          <Filter size={48} className="mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">해당 카테고리의 요청이 없습니다.</p>
        </div>
      )}
    </div>
  );
};