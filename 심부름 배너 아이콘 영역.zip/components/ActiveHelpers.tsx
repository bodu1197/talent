import React from 'react';
import { HelperInfo, Category } from '../types';
import { Star, MapPin, Bike, ShoppingBag, PenTool as Tool } from 'lucide-react';

export const ActiveHelpers: React.FC = () => {
  // Mock Active Helpers Data
  const helpers: HelperInfo[] = [
    {
      id: 'h1',
      name: '김민수',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
      currentLat: 0,
      currentLng: 0,
      distance: 0.3,
      rating: 4.9,
      reviews: 128,
      specialties: [Category.DELIVERY, Category.SHOPPING]
    },
    {
      id: 'h2',
      name: '이지은',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka',
      currentLat: 0,
      currentLng: 0,
      distance: 0.8,
      rating: 5.0,
      reviews: 42,
      specialties: [Category.CLEANING, Category.PET_CARE]
    },
    {
      id: 'h3',
      name: '박철민',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
      currentLat: 0,
      currentLng: 0,
      distance: 1.2,
      rating: 4.8,
      reviews: 315,
      specialties: [Category.BUG_CATCHING, Category.OTHER]
    }
  ];

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4 px-1">
        <h3 className="font-bold text-lg text-gray-800">지금 활동 중인 이웃 헬퍼</h3>
        <span className="text-xs text-blue-600 font-medium cursor-pointer">전체보기</span>
      </div>
      
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0">
        {helpers.map(helper => (
          <div key={helper.id} className="min-w-[260px] bg-white rounded-2xl p-4 border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-gray-100 overflow-hidden">
                <img src={helper.avatar} alt={helper.name} className="w-full h-full object-cover" />
              </div>
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
            </div>
            
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h4 className="font-bold text-gray-900">{helper.name}</h4>
                <div className="flex items-center gap-0.5 text-yellow-500 text-xs font-bold">
                  <Star size={10} fill="currentColor" />
                  <span>{helper.rating}</span>
                </div>
              </div>
              
              <div className="flex items-center gap-1 text-xs text-gray-500 mt-1 mb-2">
                <MapPin size={10} />
                <span>{helper.distance}km 이내</span>
                <span className="text-gray-300">|</span>
                <span>리뷰 {helper.reviews}</span>
              </div>

              <div className="flex gap-1">
                {helper.specialties?.slice(0, 2).map((cat, i) => (
                   <span key={i} className="px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px]">
                     {cat === Category.DELIVERY && '배달'}
                     {cat === Category.BUG_CATCHING && '벌레'}
                     {cat === Category.CLEANING && '청소'}
                     {cat === Category.PET_CARE && '돌봄'}
                     {cat === Category.SHOPPING && '장보기'}
                     {cat === Category.QUEUEING && '줄서기'}
                     {cat === Category.OTHER && '기타'}
                   </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};