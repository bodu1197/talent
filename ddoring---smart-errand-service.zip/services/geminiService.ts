import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AIAnalysisResult, Category, WeightClass } from "../types";

const apiKey = process.env.API_KEY || ""; 
const ai = new GoogleGenAI({ apiKey });

export const analyzeErrandRequest = async (rawText: string): Promise<AIAnalysisResult | null> => {
  if (!apiKey) {
    console.warn("API Key is missing. Returning mock data.");
    // Mock fallback for development without API key
    return {
        title: "요청 분석 완료",
        description: rawText,
        category: Category.DELIVERY,
        startLocation: "현위치",
        endLocation: "목적지 미상",
        estimatedWeight: WeightClass.LIGHT,
        estimatedDistance: 2.5
    };
  }

  const modelId = "gemini-2.5-flash";

  const responseSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING, description: "A concise title for the errand." },
      description: { type: Type.STRING, description: "Cleaned up description." },
      category: { 
        type: Type.STRING, 
        enum: [
          '배달/운반',
          '청소/집안일',
          '줄서기',
          '벌레잡기',
          '반려동물 케어',
          '구매대행',
          '기타'
        ]
      },
      startLocation: { type: Type.STRING, description: "Extracted start address or 'current location' if not specified." },
      endLocation: { type: Type.STRING, description: "Extracted end address." },
      estimatedWeight: {
        type: Type.STRING,
        enum: ['가벼움 (서류/음식)', '보통 (장바구니/박스)', '무거움 (가구/가전)'],
        description: "Estimated weight class based on items mentioned."
      },
      estimatedDistance: { type: Type.NUMBER, description: "Estimated distance in km (simulated)." }
    },
    required: ["title", "description", "category", "startLocation", "endLocation", "estimatedWeight", "estimatedDistance"],
  };

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `You are an intelligent dispatcher for a Korean errand service. 
      Analyze the following request: "${rawText}".
      Extract the start location and end location. If only one location is mentioned, assume it's the destination and start is 'Unknown'.
      Estimate the weight of the item.
      Estimate a realistic distance within a city context (e.g. 1km to 15km).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      return data as AIAnalysisResult;
    }
    return null;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};