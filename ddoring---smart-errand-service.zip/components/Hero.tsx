import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Hero: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-8 md:p-12 text-white shadow-xl">
        <div className="relative z-10 max-w-lg">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium mb-6">
            <Sparkles size={16} className="text-yellow-300" />
            <span>AI 매칭 시스템 도입</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
            귀찮은 일은 <br/>
            <span className="text-yellow-300">또링</span>에게 맡기세요
          </h1>
          <p className="text-blue-100 mb-8 text-lg">
            배달, 청소, 줄서기부터 벌레 잡기까지.<br />
            검증된 이웃 헬퍼가 대신 해결해드립니다.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/create" className="bg-white text-blue-600 px-6 py-3 rounded-xl font-bold hover:bg-gray-50 transition flex items-center justify-center gap-2 shadow-lg">
              심부름 요청하기 <ArrowRight size={18} />
            </Link>
            <Link to="/list" className="bg-blue-800/50 backdrop-blur-sm text-white border border-blue-400/30 px-6 py-3 rounded-xl font-medium hover:bg-blue-800/70 transition flex items-center justify-center">
              헬퍼 활동하기
            </Link>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute top-1/2 right-[-50px] md:right-[-20px] transform -translate-y-1/2 opacity-20 md:opacity-100">
           <svg width="300" height="300" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill="#FDBA74" d="M44.7,-76.4C58.9,-69.2,71.8,-59.1,81.6,-46.6C91.4,-34.1,98.1,-19.2,95.8,-5.1C93.5,9,82.3,22.3,71.4,33.5C60.5,44.7,50,53.8,38.6,61.9C27.2,70,14.9,77.1,1.5,74.5C-11.9,71.9,-26.4,59.6,-39.7,49.2C-53,38.8,-65.1,30.3,-72.2,18.7C-79.3,7.1,-81.4,-7.6,-76.3,-20.9C-71.2,-34.2,-58.9,-46.1,-46.2,-53.8C-33.5,-61.5,-20.4,-65,-6.6,-53.6L0,-42.2Z" transform="translate(100 100)" />
          </svg>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4">
            <ShieldCheck size={24} />
          </div>
          <h3 className="font-bold text-lg mb-2">신뢰할 수 있는 헬퍼</h3>
          <p className="text-gray-500 text-sm">본인 인증과 철저한 심사를 통과한 이웃들이 도와드려요.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-4">
            <Zap size={24} />
          </div>
          <h3 className="font-bold text-lg mb-2">빠른 AI 매칭</h3>
          <p className="text-gray-500 text-sm">요청 내용을 AI가 분석하여 가장 적합한 헬퍼를 찾아드려요.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
           <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mb-4">
            <span className="text-xl font-bold">₩</span>
          </div>
          <h3 className="font-bold text-lg mb-2">합리적인 가격</h3>
          <p className="text-gray-500 text-sm">AI가 적정 가격을 제안하고, 안전하게 결제할 수 있어요.</p>
        </div>
      </div>
    </div>
  );
};