import React from 'react';
import { Home, PlusCircle, Search, User, Menu } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? "text-blue-600 font-bold" : "text-gray-500 hover:text-gray-900";

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Top Navbar */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold text-xl">
              또
            </div>
            <span className="text-xl font-bold text-gray-800 tracking-tight">또링</span>
          </Link>
          
          <nav className="hidden md:flex gap-6">
             <Link to="/" className={isActive('/')}>홈</Link>
             <Link to="/list" className={isActive('/list')}>심부름 찾기</Link>
             <Link to="/create" className={isActive('/create')}>요청하기</Link>
          </nav>

          <button className="md:hidden p-2 text-gray-600">
            <Menu size={24} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 md:p-6 pb-20 md:pb-6">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-3 pb-safe z-50">
        <Link to="/" className={`flex flex-col items-center gap-1 ${isActive('/')}`}>
          <Home size={20} />
          <span className="text-xs">홈</span>
        </Link>
        <Link to="/list" className={`flex flex-col items-center gap-1 ${isActive('/list')}`}>
          <Search size={20} />
          <span className="text-xs">찾기</span>
        </Link>
        <Link to="/create" className={`flex flex-col items-center gap-1 ${isActive('/create')}`}>
          <PlusCircle size={20} />
          <span className="text-xs">요청</span>
        </Link>
        <Link to="/profile" className={`flex flex-col items-center gap-1 ${isActive('/profile')}`}>
          <User size={20} />
          <span className="text-xs">내 정보</span>
        </Link>
      </nav>
    </div>
  );
};