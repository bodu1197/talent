import React, { useState, useEffect } from 'react';
import { analyzeErrandRequest } from '../services/geminiService';
import { Errand, Category, WeatherCondition, TimeCondition, WeightClass } from '../types';
import { Wand2, Loader2, MapPin, DollarSign, CloudRain, Snowflake, Moon, Sun, Calculator, ArrowRight, Package, Scale, Clock, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ErrandFormProps {
  onSubmit: (errand: Omit<Errand, 'id' | 'createdAt' | 'status'>) => void;
}

export const ErrandForm: React.FC<ErrandFormProps> = ({ onSubmit }) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [rawInput, setRawInput] = useState('');
  const [analyzed, setAnalyzed] = useState(false);
  
  // Data States
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>(Category.OTHER);
  
  // Auto-Detected Context
  const [startLocation, setStartLocation] = useState('');
  const [endLocation, setEndLocation] = useState('');
  const [distance, setDistance] = useState<number>(0);
  const [weather, setWeather] = useState<WeatherCondition>('CLEAR');
  const [timeOfDay, setTimeOfDay] = useState<TimeCondition>('DAY');
  const [weightClass, setWeightClass] = useState<WeightClass>(WeightClass.LIGHT);
  
  const [price, setPrice] = useState<number>(0);

  // 1. Simulate Environment Detection (Weather API & Time)
  useEffect(() => {
    // Simulate Weather API call
    const weathers: WeatherCondition[] = ['CLEAR', 'CLEAR', 'RAIN', 'CLEAR', 'SNOW'];
    const randomWeather = weathers[Math.floor(Math.random() * weathers.length)];
    setWeather(randomWeather);

    // Check actual time
    const hour = new Date().getHours();
    if (hour >= 22 || hour < 6) {
        setTimeOfDay('LATE_NIGHT');
    } else if ((hour >= 7 && hour <= 9) || (hour >= 18 && hour <= 20)) {
        setTimeOfDay('RUSH_HOUR');
    } else {
        setTimeOfDay('DAY');
    }
  }, []);

  // 2. Dynamic Price Calculator
  useEffect(() => {
    if (!analyzed) return;

    let basePrice = 3000;
    
    // Distance: 1000 KRW per km
    basePrice += distance * 1200;

    // Weight Impact
    if (weightClass === WeightClass.MEDIUM) basePrice += 2000;
    if (weightClass === WeightClass.HEAVY) basePrice += 10000;

    // Weather Surcharge
    if (weather === 'RAIN') basePrice *= 1.2; // 20% surcharge
    if (weather === 'SNOW') basePrice *= 1.4; // 40% surcharge
    if (weather === 'EXTREME') basePrice *= 1.5;

    // Time Surcharge
    if (timeOfDay === 'LATE_NIGHT') basePrice += 5000;
    if (timeOfDay === 'RUSH_HOUR') basePrice += 2000;

    // Round to nearest 100 won
    setPrice(Math.round(basePrice / 100) * 100);
  }, [distance, weather, timeOfDay, weightClass, analyzed]);

  const handleAIAnalyze = async () => {
    if (!rawInput.trim()) return;

    setLoading(true);
    try {
      const result = await analyzeErrandRequest(rawInput);
      if (result) {
        setTitle(result.title);
        setDescription(result.description);
        setCategory(result.category);
        setStartLocation(result.startLocation);
        setEndLocation(result.endLocation);
        setDistance(result.estimatedDistance);
        setWeightClass(result.estimatedWeight);
        setAnalyzed(true);
      }
    } catch (error) {
      alert("AI 분석 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      title,
      description,
      category,
      price,
      startLocation,
      endLocation,
      distance,
      weather,
      timeOfDay,
      weightClass,
      isRecurring: false
    });
    navigate('/list');
  };

  const getWeatherIcon = () => {
      switch(weather) {
          case 'RAIN': return <CloudRain className="text-blue-500" />;
          case 'SNOW': return <Snowflake className="text-cyan-500" />;
          default: return <Sun className="text-orange-500" />;
      }
  };

  const getTimeIcon = () => {
      switch(timeOfDay) {
          case 'LATE_NIGHT': return <Moon className="text-purple-500" />;
          case 'RUSH_HOUR': return <Clock className="text-red-500" />;
          default: return <Sun className="text-orange-500" />;
      }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800">무엇을 도와드릴까요?</h2>
        <p className="text-gray-500 text-sm mt-1">자연스럽게 말씀해주세요. AI가 최적의 경로와 가격을 계산합니다.</p>
      </div>

      {/* Main Input Section */}
      <div className="bg-white p-6 rounded-3xl shadow-lg border-2 border-blue-100 transition-all focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-50">
        <label className="block text-sm font-bold text-gray-700 mb-3">
          요청사항 입력
        </label>
        <textarea
          rows={3}
          value={rawInput}
          onChange={(e) => setRawInput(e.target.value)}
          placeholder="예: 강남역 1번 출구 쉑쉑버거에서 햄버거 세트 하나 사서 역삼 푸르지오 103동으로 배달해줘. 비오니까 조심해서 와."
          className="w-full p-0 border-none focus:ring-0 text-lg placeholder:text-gray-300 resize-none mb-4"
        />
        <div className="flex justify-between items-center">
            <div className="text-xs text-gray-400 flex gap-2">
                <span className="bg-gray-100 px-2 py-1 rounded">☔️ 날씨 자동감지</span>
                <span className="bg-gray-100 px-2 py-1 rounded">📍 위치 자동분석</span>
            </div>
            <button
                onClick={handleAIAnalyze}
                disabled={loading || !rawInput}
                className="bg-black text-white px-6 py-3 rounded-2xl hover:bg-gray-800 disabled:opacity-50 transition flex items-center gap-2 font-bold"
            >
                {loading ? <Loader2 className="animate-spin" size={20} /> : <Wand2 size={20} />}
                <span>분석 및 견적내기</span>
            </button>
        </div>
      </div>

      {/* Smart Receipt / Analysis Result */}
      {analyzed && (
        <form onSubmit={handleSubmit} className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
          
          {/* 1. Route & Item Info */}
          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
             
             <div className="flex flex-col md:flex-row gap-6 mb-6 pb-6 border-b border-gray-100">
                <div className="flex-1 space-y-4">
                    <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                            <span className="font-bold text-xs">출발</span>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">픽업 위치</p>
                            <p className="font-bold text-gray-900">{startLocation}</p>
                        </div>
                    </div>
                    <div className="pl-4">
                         <div className="w-0.5 h-6 bg-gray-200"></div>
                    </div>
                    <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                            <span className="font-bold text-xs">도착</span>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">전달 위치</p>
                            <p className="font-bold text-gray-900">{endLocation}</p>
                        </div>
                    </div>
                </div>

                <div className="flex-1 bg-gray-50 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                         <span className="text-sm text-gray-500 flex items-center gap-2"><Package size={16}/> 물품 종류</span>
                         <span className="font-medium text-gray-900">{category}</span>
                    </div>
                    <div className="flex items-center justify-between">
                         <span className="text-sm text-gray-500 flex items-center gap-2"><Scale size={16}/> 무게 등급</span>
                         <span className={`font-medium text-xs px-2 py-1 rounded ${weightClass === WeightClass.HEAVY ? 'bg-red-100 text-red-700' : 'bg-gray-200 text-gray-700'}`}>{weightClass}</span>
                    </div>
                    <div className="flex items-center justify-between">
                         <span className="text-sm text-gray-500 flex items-center gap-2"><MapPin size={16}/> 이동 거리</span>
                         <span className="font-medium text-gray-900">{distance}km</span>
                    </div>
                </div>
             </div>
             
             <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">AI 요약 제목</label>
                <input 
                    value={title} 
                    onChange={e => setTitle(e.target.value)}
                    className="w-full font-bold text-lg border-b border-gray-200 focus:outline-none focus:border-black py-1"
                />
             </div>
          </div>

          {/* 2. Environmental Factors & Price Breakdown */}
          <div className="bg-gray-900 text-white p-6 rounded-3xl shadow-xl">
            <div className="flex items-center gap-2 mb-6 text-gray-400">
                <Calculator size={20} />
                <span className="font-bold text-sm">스마트 요금 계산기</span>
            </div>

            <div className="space-y-3 mb-8">
                <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">기본 요금</span>
                    <span>3,000원</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">거리 할증 ({distance}km)</span>
                    <span>+{(distance * 1200).toLocaleString()}원</span>
                </div>
                
                {/* Dynamic Factors */}
                <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center gap-2 text-gray-400">
                        {getWeatherIcon()} 기상 할증 ({weather === 'CLEAR' ? '맑음' : weather})
                    </span>
                    <span className={weather === 'CLEAR' ? 'text-gray-600' : 'text-yellow-400'}>
                        {weather === 'CLEAR' ? '없음' : '+20%'}
                    </span>
                </div>

                <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center gap-2 text-gray-400">
                        {getTimeIcon()} 시간대 ({timeOfDay})
                    </span>
                    <span className={timeOfDay === 'DAY' ? 'text-gray-600' : 'text-yellow-400'}>
                        {timeOfDay === 'DAY' ? '없음' : (timeOfDay === 'LATE_NIGHT' ? '+5,000원' : '+2,000원')}
                    </span>
                </div>

                 {weightClass !== WeightClass.LIGHT && (
                    <div className="flex justify-between items-center text-sm">
                        <span className="flex items-center gap-2 text-gray-400">
                            <Scale size={16} className="text-red-500"/> 무게 할증 ({weightClass})
                        </span>
                        <span className="text-yellow-400">
                            {weightClass === WeightClass.MEDIUM ? '+2,000원' : '+10,000원'}
                        </span>
                    </div>
                )}
            </div>

            <div className="border-t border-gray-700 pt-4 flex items-end justify-between">
                <div>
                    <span className="text-xs text-gray-400">최종 예상 금액</span>
                    <div className="text-3xl font-bold">{price.toLocaleString()}<span className="text-lg font-normal text-gray-400">원</span></div>
                </div>
                <button 
                    type="submit"
                    className="bg-white text-black px-6 py-3 rounded-xl font-bold hover:bg-gray-200 transition flex items-center gap-2"
                >
                    요청 등록하기 <ArrowRight size={18} />
                </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};