import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Errand, Category } from '../types';

interface StatsProps {
  errands: Errand[];
}

export const Stats: React.FC<StatsProps> = ({ errands }) => {
  // Aggregate data
  const data = Object.values(Category).map(cat => ({
    name: cat.split('/')[0], // Shorten name
    count: errands.filter(e => e.category === cat).length
  })).filter(item => item.count > 0); // Only show active

  const COLORS = ['#3B82F6', '#14B8A6', '#F43F5E', '#A855F7', '#F59E0B', '#6366F1'];

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
      <h3 className="font-bold text-lg text-gray-800 mb-4">인기 심부름 카테고리</h3>
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="name" tick={{fontSize: 12}} stroke="#9CA3AF" />
            <Tooltip 
              cursor={{fill: 'transparent'}}
              contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}}
            />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};